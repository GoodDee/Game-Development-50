﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.ComponentModel;

public class TranstoGameOver : MonoBehaviour
{
    public static int LastLevel;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
	void Update () {
		if (gameObject.transform.position.y < 0) {
            Debug.Log("falling");
            LastLevel = GrabPickups.Level;
            GrabPickups.Level = 1;
            Destroy(GameObject.Find("WhisperSource"));
			SceneManager.LoadScene("GameOver");
		}
	}
}