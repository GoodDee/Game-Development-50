﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GrabPickups : MonoBehaviour {
	public static int Level = 1;
	public Text CurrentLevel;
	private AudioSource pickupSoundSource;

	void Awake() {
		pickupSoundSource = DontDestroy.instance.GetComponents<AudioSource>()[1];
		CurrentLevel.text = "Level: " + Level;
	}

	void OnControllerColliderHit(ControllerColliderHit hit) {
		if (hit.gameObject.tag == "Pickup") {
			Level += 1;
			pickupSoundSource.Play();
			SceneManager.LoadScene("Play");
		}
	}
}
