--[[
    GD50
    Legend of Zelda

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

PlayerIdleState = Class{__includes = EntityIdleState}

function PlayerIdleState:init(player, dungeon)
	EntityIdleState:init(player)
	self.entity = player
	self.dungeon = dungeon

end

function PlayerIdleState:enter(params)
    
    -- render offset for spaced character sprite (negated in render function of state)
    self.entity.offsetY = 5
    self.entity.offsetX = 0

end

function PlayerIdleState:update(dt)
    if love.keyboard.isDown('left') or love.keyboard.isDown('right') or
       love.keyboard.isDown('up') or love.keyboard.isDown('down') then
        self.entity:changeState('walk')
    end

    if love.keyboard.wasPressed('space') then
        self.entity:changeState('swing-sword')
    end
	
	-- check if player stands next to a pot and faces it
	local bumpedPot = false
	local potToLift = nil
	for k, object in pairs(self.dungeon.currentRoom.objects) do
		if object.solid == true then
			bumpedPot = self.entity:collideWithSolid(object)
			if bumpedPot then
				potToLift = object
				break
			end
		end
	end
	
	-- if a player bumped to a pot, lift the pot
	if bumpedPot then
		if love.keyboard.wasPressed('enter') or love.keyboard.wasPressed('return') then
			potToLift:initLift()
			self.entity:changeState('pot-lift', {pot = potToLift})
		end
	end
end