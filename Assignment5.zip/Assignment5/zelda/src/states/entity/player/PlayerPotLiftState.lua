
PlayerPotLiftState = Class{__includes = BaseState}

function PlayerPotLiftState:init(player, dungeon)
	self.player = player
	self.dungeon = dungeon
	self.pot = nil
	
	self.player:changeAnimation('pot-lift-' .. self.player.direction)
end

function PlayerPotLiftState:enter(params)
	self.pot = params.pot
	self.player:changeAnimation('pot-idle')
	
	local potX, potY = self.player.x, self.player.y - self.pot.height / 2
	self.pot.x, self.pot.y = potX, potY
	--Timer.tween(0.3, {[self.pot] = {x = potX, y = potY}}).finish(
	--function()
	--	self.player:changeState('pot-idle', {pot = self.pot})
	--end)
	self.player:changeState('pot-idle', {pot = self.pot})
end

function PlayerPotLiftState:update(dt)

end

function PlayerPotLiftState:render()
	local anim = self.player.currentAnimation
	love.graphics.draw(gTextures[anim.texture], gFrames[anim.texture][anim:getCurrentFrame()],
		math.floor(self.player.x - self.player.offsetX), math.floor(self.player.y - self.player.offsetY))
		
end

