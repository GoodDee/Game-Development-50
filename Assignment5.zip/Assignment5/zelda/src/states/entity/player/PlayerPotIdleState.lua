
PlayerPotIdleState = Class{__includes = EntityIdleState}

function PlayerPotIdleState:init(player, dungeon)
	EntityIdleState:init(player)
	self.entity = player
	self.dungeon = dungeon
	self.pot = nil
	self.entity:changeAnimation('pot-idle-'.. self.entity.direction)

end

function PlayerPotIdleState:enter(params)
	self.entity.offsetY = 5
	self.entity.offsetX = 0
	self.pot = params.pot
end

function PlayerPotIdleState:update(dt)
	EntityIdleState.update(self, dt)
	
	self.pot.x = self.entity.x
	self.pot.y = self.entity.y - self.pot.height / 2
	
	if love.keyboard.isDown('left') or love.keyboard.isDown('right') or love.keyboard.isDown('up') or love.keyboard.isDown('down') then
		self.entity:changeState('pot-walk', {pot = self.pot})
	end
	
	if love.keyboard.wasPressed('enter') or  love.keyboard.wasPressed('return') then
		self.entity:changeState('pot-throw', {pot = self.pot})
	end

end

function PlayerPotIdleState:render()
	local anim = self.entity.currentAnimation
    love.graphics.draw(gTextures[anim.texture], gFrames[anim.texture][anim:getCurrentFrame()],
        math.floor(self.entity.x - self.entity.offsetX), math.floor(self.entity.y - self.entity.offsetY))
     love.graphics.setColor(255, 0, 255, 255)
     love.graphics.rectangle('line', self.entity.x, self.entity.y, self.entity.width, self.entity.height)
    love.graphics.setColor(255, 255, 255, 255)
end