--[[
    ScoreState Class
    Author: Colton Ogden
    cogden@cs50.harvard.edu

    A simple state used to display the player's score before they
    transition back into the play state. Transitioned to from the
    PlayState when they collide with a Pipe.
]]

ScoreState = Class{__includes = BaseState}

--[[
    When we enter the score state, we expect to receive the score
    from the play state so we know what to render to the State.
]]
function ScoreState:enter(params)
    self.score = params.score
	self.bronze = love.graphics.newImage('bronze.png')
	self.silver = love.graphics.newImage('silver.png')
	self.gold = love.graphics.newImage('gold.png')
end

function ScoreState:update(dt)
    -- go back to play if enter is pressed
    if love.keyboard.wasPressed('enter') or love.keyboard.wasPressed('return') then
        gStateMachine:change('countdown')
    end
end

function ScoreState:render()
    -- simply render the score to the middle of the screen
    love.graphics.setFont(flappyFont)
    love.graphics.printf('Oof! You lost!', 0, 64, VIRTUAL_WIDTH, 'center')

    love.graphics.setFont(mediumFont)
    love.graphics.printf('Score: ' .. tostring(self.score), 0, 100, VIRTUAL_WIDTH, 'center')
	
	if self.score < 4 then
		love.graphics.draw(self.bronze, (VIRTUAL_WIDTH/2) + 30, 95, 0, 0.25, 0.25)
	elseif self.score < 6 then
		love.graphics.draw(self.silver, (VIRTUAL_WIDTH/2) + 30, 95, 0, 0.25, 0.25)
	else
		love.graphics.draw(self.gold, (VIRTUAL_WIDTH/2) + 30, 95, 0, 0.25, 0.25)
	end
	
	love.graphics.setFont(smallFont)
	love.graphics.draw(self.bronze, 130, 130, 0, 0.25, 0.25)
	love.graphics.printf('Score: 0-3', 170, 140, 200)
	love.graphics.draw(self.silver, 130, 150, 0, 0.23, 0.23)
	love.graphics.printf('Score: 4-5', 170, 160, 200)
	love.graphics.draw(self.gold, 130, 170, 0, 0.2, 0.2)
	love.graphics.printf('Score: 5+', 170, 180, 200)

    love.graphics.printf('Press Enter to Play Again!', 0, 230, VIRTUAL_WIDTH, 'center')
end